var searchData=
[
  ['vertex_96',['Vertex',['../class_vertex.html',1,'Vertex'],['../class_edge.html#a1251d18f08324022e8e73506c3768f3c',1,'Edge::Vertex()']]]
];
