var indexSectionsWithContent =
{
  0: "acdefgilmnprstv",
  1: "egmv",
  2: "eglm",
  3: "acdefgilmprst",
  4: "fgins",
  5: "m",
  6: "gmv",
  7: "lp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends",
  7: "Macros"
};

